Images named "t1_x.jpg", "t2_x.jpg" and "t3_x.jpg" contain 3 types of cursors, respectively.
Images named "neg_x.jpg" do not contain the cursor.
Images named "t1.jpg", "t2.jpg", and "t3.jpg" are 3 templates corresponding to 3 types of cursors, respectively.

You are allowed to use customized templates. However, you are only allowed to use ONE template to detect each type of the cursors.