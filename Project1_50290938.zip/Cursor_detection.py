import numpy as np
import cv2 as cv

#This funciton initialises the empty matrix with zero values in it
def initialise_matrix(row, col):
    matrix = [[0 for x in range(col)] for y in range(row)]
    return matrix

#This function is used for applying the sobel filter for given Image
def getSobel(Image):
    sobelx = cv.Sobel(Image, cv.CV_64F, 1, 0, ksize=3)
    sobely = cv.Sobel(Image, cv.CV_64F, 0, 1, ksize=3)  
    OP = initialise_matrix(len(sobelx), len(sobelx[0]))
    for i in range(len(sobelx)):
        for j in range(len(sobelx[0])):
            OP[i][j] = (((sobelx[i][j]**2)+(sobely[i][j]**2))**0.5)

    return OP

#this list gets input files
listA = ["neg_1","neg_2","neg_3","neg_4","neg_5","neg_6","neg_8","neg_9","neg_10","pos_1",
"pos_2","pos_3","pos_4","pos_5","pos_6","pos_7","pos_8","pos_9","pos_10","pos_11","pos_12","pos_13","pos_14","pos_15"] 

template = cv.imread("task3/template.png", cv.IMREAD_GRAYSCALE)
resize_template = cv.resize(template, None, fx=0.55, fy=0.55)
blur_template = cv.GaussianBlur(resize_template, (3,3), 0)


for filename in listA:
    file = "./task3/"+filename+".jpg"
    img = cv.imread(file)
    gray_img = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
    w, h = resize_template.shape[::-1]
    blurredimage = cv.GaussianBlur(gray_img, (3,3), 0)
    # cv.imshow("gray",gray_img)
    # cv.imshow("gauss_blur",blurredimage)
    # cv.imshow("gauss_blur_template",blur_template)

    laplacian = cv.Laplacian(blurredimage, 10)
    lap_template = cv.Laplacian(blur_template, 10)
    #cv.imshow("laplacian", laplacian)
    #cv.imshow("lap_template",lap_template)

    #sobelImage = getSobel(gray_img)
    #sobelTemplate = getSobel(blur_template)
    #cv.imwrite("t_sample.jpg", np.asarray(sobelImage))
    #cv.imwrite("template_sample.jpg", np.asarray(sobelTemplate))
    result = cv.matchTemplate(np.asarray(laplacian).astype(np.float32), np.asarray(lap_template).astype(np.float32), cv.TM_CCOEFF_NORMED)
    loc = np.where(result >= 0.55)
    cv.imshow("result", result)

    for pt in zip(*loc[::-1]):
        cv.rectangle(img, pt, (pt[0] + w, pt[1] + h), (0, 255, 0), 3)
    fileop = filename+"_op.jpg"
    cv.imwrite(fileop,img)
