Images named "pos_x.jpg" contain the cursor, which you are asked to detect.
Images named "neg_x.jpg" do not contain the cursor.
Images named "template.jpg": template.